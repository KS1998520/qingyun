//
//  CardMO+CoreDataProperties.swift
//  lbiao
//
//  Created by 16 on 2020/1/7.
//  Copyright © 2020 16. All rights reserved.
//
//

import Foundation
import CoreData


extension CardMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CardMO> {
        return NSFetchRequest<CardMO>(entityName: "CardMO")
    }

    @NSManaged public var nr: String?
    @NSManaged public var shijian: Date?
    @NSManaged public var zhuti: String?
    @NSManaged public var tupian: Data?

}
