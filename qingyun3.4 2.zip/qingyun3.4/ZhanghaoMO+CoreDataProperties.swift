//
//  ZhanghaoMO+CoreDataProperties.swift
//  lbiao
//
//  Created by 16 on 2020/1/7.
//  Copyright © 2020 16. All rights reserved.
//
//

import Foundation
import CoreData


extension ZhanghaoMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ZhanghaoMO> {
        return NSFetchRequest<ZhanghaoMO>(entityName: "ZhanghaoMO")
    }

    @NSManaged public var number: String?
    @NSManaged public var password: String?

}
