//
//  PersonalMO+CoreDataProperties.swift
//  lbiao
//
//  Created by 16 on 2020/1/8.
//  Copyright © 2020 16. All rights reserved.
//
//

import Foundation
import CoreData


extension PersonalMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<PersonalMO> {
        return NSFetchRequest<PersonalMO>(entityName: "PersonalMO")
    }

    @NSManaged public var imagetx: Data?
    @NSManaged public var nc: String?
  

}
