//
//  PersonalMO+CoreDataClass.swift
//  lbiao
//
//  Created by 16 on 2020/1/8.
//  Copyright © 2020 16. All rights reserved.
//
//

import Foundation
import CoreData

@objc(PersonalMO)
public class PersonalMO: NSManagedObject {

}
