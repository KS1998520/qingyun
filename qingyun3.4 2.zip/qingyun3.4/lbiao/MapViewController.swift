//
//  MapViewController.swift
//  lbiao
//
//  Created by 16 on 2019/12/20.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate{
    
  @IBOutlet weak var mapView: MKMapView!
     let locationManager = CLLocationManager()
     override func viewDidLoad() {
         super.viewDidLoad()
         // Do any additional setup after loading the view.
         self.locationManager.requestAlwaysAuthorization()

         // For use in foreground
         self.locationManager.requestWhenInUseAuthorization()

         if CLLocationManager.locationServicesEnabled() {
             locationManager.delegate = self
             locationManager.desiredAccuracy = kCLLocationAccuracyBest
             locationManager.startUpdatingLocation()
         }

         mapView.delegate = self
         mapView.mapType = .standard
         mapView.isZoomEnabled = true
         mapView.isScrollEnabled = true

         if let coor = mapView.userLocation.location?.coordinate{
             mapView.setCenter(coor, animated: true)
         }
     }
     func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
         let locValue:CLLocationCoordinate2D = manager.location!.coordinate

         mapView.mapType = MKMapType.standard

       //  let span = MKCoordinateSpanMake(0.05, 0.05)
         let region = MKCoordinateRegion(center: locValue, latitudinalMeters: 100,longitudinalMeters: 100)
         mapView.setRegion(region, animated: true)

         let annotation = MKPointAnnotation()
         annotation.coordinate = locValue
         annotation.title = "我的位置"
         annotation.subtitle = "current location"
         mapView.addAnnotation(annotation)

         //centerMap(locValue)
     }

}
