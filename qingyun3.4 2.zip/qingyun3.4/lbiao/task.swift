//
//  task.swift
//  lbiao
//
//  Created by 16 on 2019/12/27.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit

class task: NSObject {
    
  
    
       var Tnr:String
       var Tshijian:String
       var Tzhuti:String
      var Ttupian:Data
    
   

    init(Tnr:String,Tshijian:String,Tzhuti:String,Ttupian:Data){

           self.Tnr = Tnr
           self.Tshijian = Tshijian
           self.Tzhuti = Tzhuti
          self .Ttupian = Ttupian
       }
}
