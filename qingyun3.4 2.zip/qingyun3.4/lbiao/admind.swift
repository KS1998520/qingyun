//
//  admind.swift
//  lbiao
//
//  Created by 16 on 2020/1/5.
//  Copyright © 2020 16. All rights reserved.
//

import UIKit

class admind: NSObject {
    
    var Zhao:String
    var Password:String

    init(Zhao:String,Password:String){
        
        self.Password = Password
        self.Zhao = Zhao
    
    }
}
