//
//  TQViewController.swift
//  lbiao
//
//  Created by 16 on 2019/12/24.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit

import CoreLocation

class TQViewController: UIViewController,CLLocationManagerDelegate{
    
    @IBOutlet weak var location: UILabel!
    
    @IBOutlet weak var wendu: UILabel!
    
    @IBOutlet weak var shidu: UILabel!
    
    @IBOutlet weak var fengsu: UILabel!
    
    @IBOutlet weak var rc: UILabel!
    
    @IBOutlet weak var rl: UILabel!
    
    @IBOutlet weak var zbaio: UILabel!
    
    @IBOutlet weak var shijian: UILabel!
    
     var refreshControl = UIRefreshControl()
    
    
    // let apiId = "12b2817fbec86915a6e9b4dbbd3d9036"
         let apiId = "2d5531ecdf0d43670c49d911afadf699"
         override func viewDidLoad() {
           super.viewDidLoad()
            
            refreshControl.addTarget(self, action: #selector(TQViewController.refreshData),
                                        for: .valueChanged)
               refreshControl.attributedTitle = NSAttributedString(string: "下拉刷新数据")
               refreshData()
          //    self.automaticallyAdjustsScrollViewInsets = false
            
           getCurrentWeatherData();
         }
    
    @objc func refreshData(){
        DispatchQueue.main.async {
            self.getCurrentWeatherData()
        }
        
    }
       func getCurrentWeatherData(){
           let urlStr = "http://api.openweathermap.org/data/2.5/weather?q=wuhu&units=metric&appid=\(apiId)"
           let url = NSURL(string: urlStr)!
           guard let weatherData = NSData(contentsOf: url as URL) else { return }
            
           do{   let jsonData = try JSON(data: weatherData as Data)
          
           let dformatter = DateFormatter()
           dformatter.dateFormat = "dd日 HH:mm:ss"
            
          location.text = (jsonData["name"].string!)
      
           let temp = jsonData["main"]["temp"].number!
            wendu.text = (temp).stringValue + "C"
          
            
           let humidity = jsonData["main"]["humidity"].number!
          
            shidu.text = (humidity).stringValue
            
         
            
           let windSpeed = jsonData["wind"]["speed"].number!
          
            fengsu.text = (windSpeed).stringValue
            
           let lon = jsonData["coord"]["lon"].number!
          // let lat = jsonData["coord"]["lat"].number!
         
            zbaio.text = lon.stringValue
            
           let timeInterval1 = TimeInterval(truncating: jsonData["sys"]["sunrise"].number!)
           let date1 = NSDate(timeIntervalSince1970: timeInterval1)
          
            rc.text = dformatter.string(from: date1 as Date)
            
           let timeInterval2 = TimeInterval(truncating: jsonData["sys"]["sunset"].number!)
           let date2 = NSDate(timeIntervalSince1970: timeInterval2)
         
            rl.text = dformatter.string(from: date2 as Date)
            
           let timeInterval3 = TimeInterval(truncating: jsonData["dt"].number!)
           let date3 = NSDate(timeIntervalSince1970: timeInterval3)
        
            shijian.text = dformatter.string(from: date3 as Date)
           }catch{}
       }
    
       override func didReceiveMemoryWarning() {
           super.didReceiveMemoryWarning()
       }
   
    
}
