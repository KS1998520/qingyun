//
//  messageViewController.swift
//  lbiao
//
//  Created by 16 on 2020/1/8.
//  Copyright © 2020 16. All rights reserved.
//

import UIKit
import Foundation
import  CoreData

class messageViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    let imagePickerController = UIImagePickerController()
       var imageData: Data?
   

    @IBOutlet weak var imagetx: UIImageView!
    
    @IBOutlet weak var nc: UITextField!
   
    
    var appDelegate: AppDelegate!
    var context: NSManagedObjectContext!
    
     private let CpersonalMO = "PersonalMO"
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = true
        
        appDelegate = UIApplication.shared.delegate as? AppDelegate
        context = appDelegate.persistentContainer.viewContext
        
        loadData()
        
        imagetx.contentMode = .scaleAspectFill
            
        imagetx.layer.masksToBounds = true
            
        imagetx.layer.cornerRadius = imagetx.frame.width/2

      //  insertData()
    }
    
    @IBAction func baoc(_ sender: Any) {
         insertData()
        let nextpage = self.storyboard?.instantiateViewController(withIdentifier: "nextVT")  as! UITabBarController
                           self.present(nextpage,animated: true,completion: nil)
        
    }
    @IBAction func addPicker(_ sender: UIButton) {
         
         let pickerActionSheeet = UIAlertController(title: "选取图片", message: "您可以从以下几种方式选择图片", preferredStyle: .actionSheet)
         if UIImagePickerController.isSourceTypeAvailable(.camera){
             let camera = UIAlertAction(title: "相机", style: .default){ (alertAction) in
                 self.imagePickerController.sourceType = .camera
                 self.present(self.imagePickerController,animated: true){
                 }
                 
             }
             pickerActionSheeet.addAction(camera)
         }
         let photoLibrary = UIAlertAction(title: "媒体库", style: .default){ (alertAction) in
                    self.imagePickerController.sourceType = .photoLibrary
                    self.present(self.imagePickerController,animated: true){
                    }
                    
                }
                    pickerActionSheeet.addAction(photoLibrary)
         
         let savedPhotosAlbum = UIAlertAction(title: "相册", style: .default){ (alertAction) in
                       self.imagePickerController.sourceType = .savedPhotosAlbum
                       self.present(self.imagePickerController,animated: true){
                       }
                       
                   }
                 pickerActionSheeet.addAction(savedPhotosAlbum)
         let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                 pickerActionSheeet.addAction(cancel)
         present(pickerActionSheeet,animated: true,completion: nil)
     }
     func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
         dismiss(animated: true, completion: nil)
         let image = info[.editedImage] as! UIImage
         imageData = image.pngData()
         saveImage(image: image, toPath: getDocumentsDirectory(), byName: "tx.jpg")
     }
     func saveImage(image:UIImage,toPath path : String,byName name :String){
         let imagePath = URL(fileURLWithPath: path).appendingPathComponent(name)
         let imageData = image.jpegData(compressionQuality: 1.0)
         try? imageData?.write(to:imagePath)
         
         imagetx.image = image
     }
     func getDocumentsDirectory()-> String{
         return
             NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
         
     }
  
    
    
    func loadData() {
           // 1、创建实体
           let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
           // 2、创建查询
           let entity = NSEntityDescription.entity(forEntityName:CpersonalMO, in:
               context)
           // 3、指定查询的实体
           fetchRequest.entity = entity
           // 4、创建查询后数据的存储容器objects
             //var objects: [CardMO]?
    
           do{
             let  objects = try context.fetch(fetchRequest) as? [PersonalMO]
               for mo in objects!{
                   imagetx.image =  UIImage(data: mo.imagetx!)
                   nc.text = mo.nc
               }
           }catch{
           }
       }
    
    
    func insertData()  {
        if nc.text == ""{
            let alert = UIAlertController(title: "内容不能为空", message: nil, preferredStyle: .alert)
                                  alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
            present(alert ,animated: true,completion: nil)
        }else{
        
        let Cardmo1 = NSEntityDescription.insertNewObject(forEntityName: CpersonalMO, into: context) as! PersonalMO
        Cardmo1.imagetx = imageData
        Cardmo1.nc = nc.text
       //  Cardmo1.tupian = imageData
         appDelegate.saveContext()
    }
    }

       

    }


