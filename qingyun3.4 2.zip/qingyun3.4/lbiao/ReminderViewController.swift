//
//  ReminderViewController.swift
//  lbiao
//
//  Created by 16 on 2020/1/1.
//  Copyright © 2020 16. All rights reserved.
//

import UIKit
import EventKit

class ReminderViewController: UIViewController{

    
    var eventStore: EKEventStore!
       var reminders: [EKReminder]!
       var tableView:UITableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.eventStore = EKEventStore()
              self.reminders = [EKReminder]()
              self.eventStore.requestAccess(to: .reminder) {
                  (granted: Bool, error: Error?) in
                   
                  if granted{
                      // 获取授权后，我们可以得到所有的提醒事项
                      let predicate = self.eventStore.predicateForReminders(in: nil)
                      self.eventStore.fetchReminders(matching: predicate, completion: {
                          (reminders: [EKReminder]?) -> Void in
                           
                          self.reminders = reminders
                          print(self.reminders.count)
                          DispatchQueue.main.async{
                              self.tableView?.reloadData()
                          }
                      })
                  }else{
                      print("获取提醒失败！需要授权允许对提醒事项的访问。")
                  }
              }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
           return 1
       }
        
       //返回表格行数（也就是返回控件数）
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return self.reminders.count
       }
    
       //创建各单元显示内容(创建参数indexPath指定的单元）
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)
           -> UITableViewCell {
           let cell = UITableViewCell(style: .subtitle,
                                      reuseIdentifier: "myCell")
           let reminder:EKReminder! = self.reminders![indexPath.row]
            
           //提醒事项的内容
           cell.textLabel?.text = reminder.title
            
           //提醒事项的时间
           let formatter = DateFormatter()
           formatter.dateFormat = "yyyy-MM-dd"
           if let dueDate = reminder.dueDateComponents?.date{
               cell.detailTextLabel?.text = formatter.string(from: dueDate)
           }else{
               cell.detailTextLabel?.text = "N/A"
           }
           return cell
       }
        
       override func didReceiveMemoryWarning() {
           super.didReceiveMemoryWarning()
       }
}
