//
//  OneViewController.swift
//  lbiao
//
//  Created by 16 on 2019/12/16.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit
import CoreData

class OneViewController: UIViewController {
       var showMenu = false;
    
       private let CpersonalMO = "PersonalMO"
       var appDelegate: AppDelegate!
       var context: NSManagedObjectContext!
    @IBOutlet weak var imageTX: UIImageView!
    
    @IBOutlet weak var leadingConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var name: UILabel!
    @IBAction func Map(_ sender: Any) {
//         let nextpage = storyboard?.instantiateViewController(withIdentifier: "nextVMap")  as! MapViewController
//          present(nextpage,animated: true,completion: nil)
    }
    
    @IBOutlet var viewBackgroud: UIView!
    @IBAction func BianX(_ sender: Any) {
        
//              let nextpage = storyboard?.instantiateViewController(withIdentifier: "nextVS")  as! SpeechController
//             self.navigationController?.pushViewController(nextpage, animated: true)
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        appDelegate = UIApplication.shared.delegate as? AppDelegate
             
        context = appDelegate.persistentContainer.viewContext
        
        loadData()
        
        imageTX.contentMode = .scaleAspectFill
       
        imageTX.layer.masksToBounds = true
       
        imageTX.layer.cornerRadius = imageTX.frame.width/2
       
    }
    
     func loadData() {
            // 1、创建实体
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
            // 2、创建查询
            let entity = NSEntityDescription.entity(forEntityName:CpersonalMO, in:
                context)
            // 3、指定查询的实体
            fetchRequest.entity = entity
            // 4、创建查询后数据的存储容器objects
              //var objects: [CardMO]?
     
            do{
              let  objects = try context.fetch(fetchRequest) as? [PersonalMO]
                for mo in objects!{
                    imageTX.image =  UIImage(data: mo.imagetx!)
                    name.text = mo.nc
                }
            }catch{
            }
        }
    @IBAction func openMenu(_ sender: Any) {
        
        if(showMenu){
                  leadingConstraint.constant = -170;
                  viewBackgroud.backgroundColor = UIColor.white
                  UIView.animate(withDuration: 0.4, animations: self.view.layoutIfNeeded)
              }else{
                  leadingConstraint.constant = 0;
                  viewBackgroud.backgroundColor = UIColor.darkGray
                    UIView.animate(withDuration: 0.4, animations: self.view.layoutIfNeeded)
              }
              
              showMenu = !showMenu
          }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


