//
//  Reminder.swift
//  lbiao
//
//  Created by 16 on 2020/1/1.
//  Copyright © 2020 16. All rights reserved.
//

//import Foundation
//import UIKit
//import UserNotifications
//
//class Reminder:NSObject,NSCoding{
//   
//    
//    //var notification:UserNotifications
//    var notification:UILocalNotification
//    var name:String = ""
//    var time:NSDate
//    
//    static let DocumentsDirector = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
//     static let ArchiveURl = DocumentsDirector.appendingPathComponent("reminder")
//  //  static let ArchiveURl = DocumentsDirector.appendingPathComponent("reminder", isDirectory: true)
//    
//    static func PropertyKey() {
//        let nameKey = "name"
//        let timeKey = "time"
//        let notificatinKey = "notification"
//    
//    
//    }
//    init(name:String,time:NSDate,notification:UILocalNotification){
//    self.name = name
//    self.time = time
//    self.notification = notification
//       
//        super.init()
//    }
//    
//    deinit{
//        UIApplication.shared.can(self.notification)
//    }
//}
