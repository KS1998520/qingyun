//
//  SpeechController.swift
//  lbiao
//
//  Created by 16 on 2019/12/15.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit
import Speech
import Foundation
import  CoreData

class SpeechController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    
//    var tasks = [task]()
//    let TASK = task(Tnr: "", Tshijian: "", Tzhuti: "")
    let imagePickerController = UIImagePickerController()
    var imageData: Data?
   
    
    
    @IBOutlet weak var da: UIImageView!
    var appDelegate: AppDelegate!
    var context: NSManagedObjectContext!
    private let Ccard = "CardMO"
    
    @IBOutlet weak var ZTi: UITextField!
    @IBOutlet weak var startStopBtn: UIButton!
    @IBOutlet weak var segmentCtr: UISegmentedControl!
    
    @IBOutlet weak var textView: UITextView!
    
    //
    @IBAction func addPicker(_ sender: UIButton) {
        
        let pickerActionSheeet = UIAlertController(title: "选取图片", message: "您可以从以下几种方式选择图片", preferredStyle: .actionSheet)
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let camera = UIAlertAction(title: "相机", style: .default){ (alertAction) in
                self.imagePickerController.sourceType = .camera
                self.present(self.imagePickerController,animated: true){
                }
            }
            pickerActionSheeet.addAction(camera)
        }
        let photoLibrary = UIAlertAction(title: "媒体库", style: .default){ (alertAction) in
                   self.imagePickerController.sourceType = .photoLibrary
                   self.present(self.imagePickerController,animated: true){
                   }
                   
               }
                   pickerActionSheeet.addAction(photoLibrary)
        
        let savedPhotosAlbum = UIAlertAction(title: "相册", style: .default){ (alertAction) in
                      self.imagePickerController.sourceType = .savedPhotosAlbum
                      self.present(self.imagePickerController,animated: true){
                      }
                      
                  }
                pickerActionSheeet.addAction(savedPhotosAlbum)
        let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                pickerActionSheeet.addAction(cancel)
        present(pickerActionSheeet,animated: true,completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        dismiss(animated: true, completion: nil)
        let image = info[.editedImage] as! UIImage
        imageData = image.pngData()
        saveImage(image: image, toPath: getDocumentsDirectory(), byName: "bg.jpg")
    }
    func saveImage(image:UIImage,toPath path : String,byName name :String){
        let imagePath = URL(fileURLWithPath: path).appendingPathComponent(name)
        let imageData = image.jpegData(compressionQuality: 1.0)
        try? imageData?.write(to:imagePath)
        
        da.image = image
    }
    func getDocumentsDirectory()-> String{
        return
            NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
    }
        
        
    //
    @IBAction func Save(_ sender: Any) {
        
        insertData()
        
        //tasks.insert(TASK, at: 0)
        let nextpage = storyboard?.instantiateViewController(withIdentifier: "nextVcell")  as! UINavigationController
        present(nextpage,animated: true,completion: nil)
        
    }
    
    
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier:"zh-cn"))
    private var recognitioRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitioTask: SFSpeechRecognitionTask?
    private var audioEngine = AVAudioEngine()
    
    var lang: String = "zh-cn"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = true
        
        appDelegate = UIApplication.shared.delegate as? AppDelegate
        context = appDelegate.persistentContainer.viewContext
        

        startStopBtn.isEnabled = false
        speechRecognizer?.delegate = self as? SFSpeechRecognizerDelegate //3
        speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: lang))
        SFSpeechRecognizer.requestAuthorization{(authStatus) in
            var isButtonEnable = false
            
            switch authStatus{
            case.authorized:
                isButtonEnable = true
                
            case.denied:
                isButtonEnable = false
                print("User denied access to speech recognition")
                
            case.restricted:
                isButtonEnable = false
                print("Speech recognition restricted on this device")
                
            case.notDetermined:
                isButtonEnable = false
                print("Speech recognition not yet authorized")
            @unknown default:
                print("Speech recognition not yet authorized")
            }
            OperationQueue.main.addOperation(){
                self.startStopBtn.isEnabled =  isButtonEnable
            }
            
            
        }
        
        // Do any additional setup after loading the view.
    }
    @IBAction func segmentAct(_ sender: Any) {
        switch segmentCtr.selectedSegmentIndex{
        case 0:
            print("0")
            lang = "zh-cn"
            break;
        case 1:
            print("1")
            lang = "en-US"
            break;
        case 2:
            print("2")
            lang = "tt-RU"
            break;
        case 3:
            print("3")
            lang = "ko-kr"
            break;
        case 4:
            print("4")
            lang = "ia-JP"
            break;
        default:
            lang = "zh-cn"
            break;
        }
        
        speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier:lang))
    }
    
    
    @IBAction func startStopAct(_ sender: Any) {
        speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier:lang))
        if audioEngine.isRunning{
            audioEngine.stop()
            recognitioRequest?.endAudio()
            startStopBtn.isEnabled = false
            startStopBtn.setTitle("开始录音", for: .normal)
        }else{
            startRecording()
            startStopBtn.setTitle("停止录音", for: .normal)
        }
    }
    func  startRecording(){
        if recognitioTask != nil{
            recognitioTask?.cancel()
            recognitioTask = nil
        }
        let audioSession = AVAudioSession.sharedInstance()
        do{
//            try audioSession.setCategory(AVAudioSessionCategoryRecord)
//            try audioSession.setMode(AVAudioSessionModeMeasurement)
//            try audioSession.setActive(true, with:.notifyOthersOnDeactivation)
            try audioSession.setCategory(AVAudioSession.Category.record)
            try audioSession.setMode(AVAudioSession.Mode.measurement)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
            
            
        }catch{
            print("audioSession properties weren't set because of an error.")
        }
        recognitioRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        
        guard let recognitionRequest = recognitioRequest else{
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        
        recognitionRequest.shouldReportPartialResults = true
        
        recognitioTask = speechRecognizer?.recognitionTask(with: recognitionRequest,resultHandler:{
            (result,error) in
            var isFinal = false
            if result != nil{
                self.textView.text = result?.bestTranscription.formattedString
                isFinal = (result?.isFinal)!
            }
            if error != nil || isFinal{
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.recognitioRequest = nil
                self.recognitioTask = nil
                
                self.startStopBtn.isEnabled = true
            }
        })
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024,format: recordingFormat){
            (buffer,when) in
            self.recognitioRequest?.append(buffer)
        }
        audioEngine.prepare()
        do{
            try audioEngine.start()
        }catch{
            print("audioEngine couldn't start because of an error")
        }
        textView.text = "请说点什么，我在听"
        
    }
    func speechRecognizer(_speechRecognizer:SFSpeechRecognizer,availabilityDidChange  available:
        Bool){
        if available{
            startStopBtn.isEnabled = true
        }else{
            startStopBtn.isEnabled = false
        }
        
    }
    
    //
    func insertData()  {
    
        if textView.text == "" {
            let alert = UIAlertController(title: "内容不能为空", message: nil, preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
                          present(alert ,animated: true,completion: nil)
    }else{
        let Cardmo1 = NSEntityDescription.insertNewObject(forEntityName: Ccard, into: context) as! CardMO
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        Cardmo1.nr = textView.text
        Cardmo1.zhuti = ZTi.text
        Cardmo1.shijian = Date()
        Cardmo1.tupian = imageData
        appDelegate.saveContext()
    }

    }

  }
