//
//  DesignView.swift
//  lbiao
//
//  Created by 16 on 2019/12/13.
//  Copyright © 2019 16. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable class DesignView : UIView {
    
        var cornerRadius : CGFloat = 22
        var interitemSpacing : CGFloat = 50
        var shadowColor : UIColor? = UIColor.black
        var shadowOffSetwidth : Int = 5
        var shadeowOffSetHeight : Int = 1
        var shadowOpacity : Float = 0.2
    

    override func layoutSubviews() {
        layer.cornerRadius = cornerRadius
        layer.shadowColor = shadowColor?.cgColor
        layer.shadowOffset = CGSize(width: shadowOffSetwidth, height: shadeowOffSetHeight)
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius)
        layer.shadowPath = shadowPath.cgPath
        layer.shadowOpacity = shadowOpacity
        
    }
    
}

