//
//  DngLViewController.swift
//  lbiao
//
//  Created by 16 on 2019/12/25.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit
import  CoreData
import LocalAuthentication

class DngLViewController: UIViewController {

    var appDelegate: AppDelegate!
    
    var context: NSManagedObjectContext!
    let Czhanghaomo = "ZhanghaoMO"
    
    @IBOutlet weak var ZHao: UITextField!
    
    @IBOutlet weak var Mma: UITextField!
    
    
    var admins = [admind]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        appDelegate = UIApplication.shared.delegate as? AppDelegate
               
        context = appDelegate.persistentContainer.viewContext
         
        loadData()

    }
    
    @IBAction func DengL(_ sender: Any) {
        for index in 0..<admins.count{
            let adminders = admins[index]
            if adminders.Zhao == ZHao.text{
                if adminders.Password == Mma.text {
                    let nextpage = self.storyboard?.instantiateViewController(withIdentifier: "nextVT")  as! UITabBarController
                                                      self.present(nextpage,animated: true,completion: nil)
                }else{
                    let alert = UIAlertController(title: "账号或密码错误", message: nil, preferredStyle: .alert)
                                          alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
                                             present(alert ,animated: true,completion: nil)
                    break;
                }
                
            }

//        if  adminders.Zhao ==  ZHao.text && adminders.Password != Mma.text{
//            let alert = UIAlertController(title: "账号或密码错误", message: nil, preferredStyle: .alert)
//                       alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
//                          present(alert ,animated: true,completion: nil)
//        }else{
//            let nextpage = self.storyboard?.instantiateViewController(withIdentifier: "nextVT")  as! UITabBarController
//                                   self.present(nextpage,animated: true,completion: nil)
//
//        }
        }
    }
    
     func loadData() {
           
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
            let entity = NSEntityDescription.entity(forEntityName:Czhanghaomo, in:context)
            fetchRequest.entity = entity
            var objects: [ZhanghaoMO]?
       
            do{
               objects = try context.fetch(fetchRequest) as? [ZhanghaoMO]
                for mo in objects!{
                      let admin = admind(Zhao: "", Password: "")
                     admin.Zhao = mo.number!
                     admin.Password = mo.password!
                     admins.append(admin)
                }
               
            }catch{
                if objects == nil{
                    print("查询失败")
                }
            }
        }
    
    
    //Face ID
   @IBAction func FaceID(_ sender: Any) {
        let context = LAContext()
        var error:NSError?
   
        if context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error){
            let reason = "Identify yourself"
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason){[weak self] success,
                authenticationError in
                DispatchQueue.main.async{
                    if success{
                      DispatchQueue.main.async {
                        let nextpage = self?.storyboard?.instantiateViewController(withIdentifier: "nextVT")  as! UITabBarController
                        self?.present(nextpage,animated: true,completion: nil)
                        }
                    }else{
                        //error
                        let ac = UIAlertController(title:"Authentication failed",message:"You could not be verified; please try again.",preferredStyle: .alert)
                        ac.addAction(UIAlertAction(title:"ok",style: .default))
                        self?.present(ac,animated: true)
                    }
                }
            }
        }else{
//            no biometry
            let ac = UIAlertController(title:"Authentication failed",message:"You could not be verified; please try again.",preferredStyle: .alert)
                ac.addAction(UIAlertAction(title:"ok",style: .default))
               self.present(ac,animated: true)
        }
    
    }
//    func  ShowAlertController(_message: String){
//          let alertController = UIAlertController(title: nil, message: _message, preferredStyle: .alert)
//          alertController.addAction(UIAlertAction(title:"ok",style:.default, handler: nil))
//          present(alertController,animated: true,completion: nil)
//      }
    
//Touch ID
    @IBAction func TouchID(_ sender: Any) {
        let context = LAContext()
        var error: NSError?
        
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error){
            let reason = "请求指纹"
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason, reply: {(succes, error) in
                if succes {
                    DispatchQueue.main.async {
                        let nextpage = self.storyboard?.instantiateViewController(withIdentifier: "nextVT")  as! UITabBarController
                        self.present(nextpage,animated: true,completion: nil)
                    }
                }
                else{
//                    self.showAlertController(_message: "指纹验证失败")
                }
            })
        }
        else{
//           showAlertController(_message: "指纹不可用")
        }
    }
    func  showAlertController(_message: String){
        let alertController = UIAlertController(title: nil, message: "无法验证，请从试", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title:"ok",style:.default, handler: nil))
        present(alertController,animated: true,completion: nil)
        
        
       
    }
  
}
