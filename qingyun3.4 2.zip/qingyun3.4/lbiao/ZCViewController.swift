//
//  ZCViewController.swift
//  lbiao
//
//  Created by 16 on 2019/12/23.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit
import  CoreData

class ZCViewController: UIViewController {

    @IBOutlet weak var viewOne: UIView!
    
    @IBOutlet weak var viewTwo: UIView!
    
    @IBOutlet weak var viewThree: UIView!
    
    @IBOutlet weak var topCHeight: NSLayoutConstraint!
    
    @IBOutlet weak var LogoCHeight: NSLayoutConstraint!
    
    @IBOutlet weak var zhanghao: UITextField!
    @IBOutlet weak var mima: UITextField!
    
    @IBOutlet weak var imagetb: UIImageView!
    
   
    var admins = [admind]()
    
    var appDelegate: AppDelegate!
    var context: NSManagedObjectContext!
    let Czhanghaomo = "ZhanghaoMO"
    
    @IBAction func next(_ sender: Any) {
        mima.becomeFirstResponder();
    }
    
    @IBAction func receoveK(_ sender: Any) {
        mima.resignFirstResponder();
        
    }
    @IBAction func fh(_ sender: Any) {
        zhanghao.resignFirstResponder()
        mima.resignFirstResponder()
    }
    
    @IBAction func back(_ sender: Any) {
        viewTwo.isHidden = true
           topCHeight.constant = 742;
           LogoCHeight.constant = 188;
           UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: .curveEaseOut, animations:{self.view.layoutIfNeeded()},completion: nil)
        
    }
    @IBAction func TJ(_ sender: Any) {
        
    if zhanghao.text == ""&&mima.text == ""{
        let alert = UIAlertController(title: "登录的手机号码或密码不能为空", message: nil, preferredStyle: .alert)
             alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
                present(alert ,animated: true,completion: nil)
        }
        
     let mobile = "^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$"
     let regexMobile = NSPredicate(format: "SELF MATCHES %@",mobile)
        
    if regexMobile.evaluate(with: zhanghao.text) == true
        {
          
            let alert = UIAlertController(title: "注册成功", message: nil, preferredStyle: .alert)
             alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
            present(alert ,animated: true,completion: nil)
            
            insertData()
           
            viewTwo.isHidden = true
                 topCHeight.constant = 742;
                 LogoCHeight.constant = 188;
                 UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: .curveEaseOut, animations:{self.view.layoutIfNeeded()},completion: nil)
          
        }else{
            let alert = UIAlertController(title: "登录的手机号码格式不正确", message: nil, preferredStyle: .alert)
                 alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
                present(alert ,animated: true,completion: nil)
        }

    }
    
    @IBAction func ZC(_ sender: Any) {
        
       viewTwo.isHidden = false
                topCHeight.constant = 200;
                  LogoCHeight.constant = 88;
                  UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: .curveEaseOut, animations:{self.view.layoutIfNeeded()},completion: nil)
                
            }
            override func viewDidLoad() {
                viewThree.isHidden = true
                super.viewDidLoad()
                viewTwo.isHidden = true
                LogoCHeight.constant = 188;
                topCHeight.constant = 742;
                
                appDelegate = UIApplication.shared.delegate as? AppDelegate
                     
                context = appDelegate.persistentContainer.viewContext
                
                
            
               
                //页面停留
//              viewOne.isHidden = turn
//                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2){
//                self.performSegue(withIdentifier:"nextpage", sender: nil)
//                }
            }
            
            func insertData()  {
              
                  let Cardmo1 = NSEntityDescription.insertNewObject(forEntityName: Czhanghaomo, into: context) as! ZhanghaoMO
                  Cardmo1.number = zhanghao.text
                  Cardmo1.password = mima.text

                  appDelegate.saveContext()

              }
            func bduan(){
                
            }
        }
    
    


