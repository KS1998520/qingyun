//
//  cellViewController.swift
//  lbiao
//
//  Created by 16 on 2019/12/26.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit
import  CoreData

class cellViewController: UIViewController,UITableViewDataSource, UITableViewDelegate{
    
    
    @IBOutlet weak var topCHeight: NSLayoutConstraint!
    
    @IBOutlet weak var viewOne: UIView!
    
    @IBOutlet weak var viewTwo: UIView!
    
    @IBOutlet var viewBackground: UIView!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var textViewNr: UITextView!
    
    @IBOutlet weak var labelZhuti: UILabel!
    
    @IBOutlet weak var labelShijian: UILabel!
    
    @IBOutlet weak var image2: UIImageView!
    
    var appDelegate: AppDelegate!
    
    var context: NSManagedObjectContext!
    
    var tasks = [task]()
    
//    let formatter = DateFormatter()
//    formatter.dateFormat = "yyyy-MM-dd HH:mm"
    
    var refreshControl = UIRefreshControl()
    
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        
        refreshControl.addTarget(self, action: #selector(ViewController.refreshData),
                                                  for: .valueChanged)
        refreshControl.attributedTitle = NSAttributedString(string: "下拉刷新数据")
        tableView?.addSubview(refreshControl)
        refreshData()
        
        viewTwo.isHidden = true
        topCHeight.constant = 579
        
        appDelegate = UIApplication.shared.delegate as? AppDelegate
        
        context = appDelegate.persistentContainer.viewContext
        
        loadData()
       
        let longpress = UILongPressGestureRecognizer(target: self, action:
            #selector(longpressGestureOperation(gesture:)))
        longpress.numberOfTouchesRequired = 1
        longpress.minimumPressDuration = 0.5
        tableView.addGestureRecognizer(longpress)
  }
       
    
    @objc func longpressGestureOperation(gesture: UILongPressGestureRecognizer){
    
        
    }
    
      
    
    //定义常量
    private let Ccard = "CardMO"
    
    
    func loadData() {
        // 1、创建实体
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
        // 2、创建查询
        let entity = NSEntityDescription.entity(forEntityName:Ccard, in:
            context)
        // 3、指定查询的实体
        fetchRequest.entity = entity
        // 4、创建查询后数据的存储容器objects
          //var objects: [CardMO]?
 
        do{
          let  objects = try context.fetch(fetchRequest) as? [CardMO]
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm"
            for mo in objects!{
                
                let data = Data()
                
                let TASK = task(Tnr: "", Tshijian: "", Tzhuti: "", Ttupian: data)
                TASK.Tzhuti = mo.zhuti!
                TASK.Tnr = mo.nr!
                TASK.Ttupian = mo.tupian!
                let date = formatter.string(from: mo.shijian! as Date)
                TASK.Tshijian = date
            
           
                tasks.insert(TASK,at:0)
            }
            tableView.reloadData()
        }catch{
        }
    }

    
    func deleteContact(by zhuti:String){
                 let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
                 let entity = NSEntityDescription.entity(forEntityName:Ccard, in:
                     context)
                 fetchRequest.entity = entity
                let predicate = NSPredicate(format: "zhuti==%@", zhuti)
              fetchRequest.predicate = predicate
                
                 var objects: [CardMO]?
                do{
                    objects = try context.fetch(fetchRequest) as? [CardMO]
                    for mo in objects!{
                      context.delete(mo)
                    }
                }catch{
                    if objects == nil{
                        print("查询失败")
          }
       }
    }
    //view数据
    @IBAction func XQ(_ sender: Any) {
        // viewOne.backgroundColor = UIColor.black
        viewTwo.isHidden = false
        topCHeight.constant = 280
        UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: .curveEaseOut, animations:{self.view.layoutIfNeeded()},completion: nil)
    }
    
    
    @IBAction func baoC(_ sender: Any) {
        viewTwo.isHidden = true
        UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0,
                       options: .curveEaseOut, animations:{self.view.layoutIfNeeded()},completion: nil)
        
    }
    @IBAction func `return`(_ sender: Any) {
        viewTwo.isHidden = true
        UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: .curveEaseOut, animations:{self.view.layoutIfNeeded()},completion: nil)
    }
    
    
    
    //cell数据
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        160
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    
    func tableView(_ tableView:UITableView,cellForRowAt indexPath:IndexPath) -> UITableViewCell{
        
        
        let reuseID = "taskCell"
        
        var cell = tableView.dequeueReusableCell(withIdentifier: reuseID) as? taskcellTableViewcell
      //  var cell : taskcellTableViewcell! = tableView.dequeueReusableCell(withIdentifier: reuseID, for: indexPath) as! taskcellTableViewcell
        if cell == nil {
            cell = taskcellTableViewcell(style: .default, reuseIdentifier: reuseID)
        }
        
        let task = tasks[indexPath.row]
        cell?.tag = indexPath.row
        cell?.Zhuti.text = task.Tzhuti
        cell?.Shijian.text = task.Tshijian
        cell?.NR.text = task.Tnr
        cell?.image1.image = UIImage(data: task.Ttupian)
        
        

        return cell!
        
    }
    @objc func refreshData(){
             
                // self.getCurrentWeatherData()
               self.refreshControl.endRefreshing()
             
             
         }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let TASK = tasks[indexPath.row]
        textViewNr.text = TASK.Tnr
        labelZhuti.text = TASK.Tzhuti
        labelShijian.text = TASK.Tshijian
        image2.image = UIImage(data: TASK.Ttupian)

          viewTwo.isHidden = false
          topCHeight.constant = 280
          UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: .curveEaseOut, animations:{self.view.layoutIfNeeded()},completion: nil)
        
        
    }
}
    


