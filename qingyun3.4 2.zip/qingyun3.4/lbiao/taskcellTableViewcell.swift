//
//  taskcellTableViewcell.swift
//  lbiao
//
//  Created by 16 on 2019/12/26.
//  Copyright © 2019 16. All rights reserved.
//

import UIKit

class taskcellTableViewcell: UITableViewCell {

    @IBOutlet weak var Shijian: UILabel!
    @IBOutlet weak var NR: UILabel!

    @IBAction func XQ(_ sender: Any) {
    }
    @IBOutlet weak var Zhuti: UILabel!
    @IBOutlet weak var image1: UIImageView!
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(taskcellTableViewcell()))
//            addGestureRecognizer(tapGesture)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    

        // Configure the view for the selected state
    }

}
