//
//  zcTwoViewController.swift
//  lbiao
//
//  Created by 16 on 2020/1/8.
//  Copyright © 2020 16. All rights reserved.
//

import UIKit
import  CoreData

class zcTwoViewController: UIViewController {

    @IBOutlet weak var zhanghaoTwo: UITextField!
    
    @IBOutlet weak var mimaTwo: UITextField!
     var admins = [admind]()
    var appDelegate: AppDelegate!
       var context: NSManagedObjectContext!
       let Czhanghaomo = "ZhanghaoMO"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        appDelegate = UIApplication.shared.delegate as? AppDelegate
                            
        context = appDelegate.persistentContainer.viewContext
       
    }
    

    @IBAction func TJ(_ sender: Any) {
        if zhanghaoTwo.text == ""&&mimaTwo.text == ""{
            let alert = UIAlertController(title: "登录的手机号码或密码不能为空", message: nil, preferredStyle: .alert)
                 alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
                    present(alert ,animated: true,completion: nil)
            }
            
         let mobile = "^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$"
         let regexMobile = NSPredicate(format: "SELF MATCHES %@",mobile)
            
        if regexMobile.evaluate(with: zhanghaoTwo.text) == true
            {
              
                let alert = UIAlertController(title: "注册成功", message: nil, preferredStyle: .alert)
                 alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
               // present(alert ,animated: true,completion: nil)
            
                DispatchQueue.main.async {
                    let nextpage = self.storyboard?.instantiateViewController(withIdentifier: "nextMess")  as! messageViewController
                    self.present(nextpage,animated: true,completion: nil)
                } 
                
                insertData()
        }else{
            let alert = UIAlertController(title: "登录的手机号码格式不正确", message: nil, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
                   present(alert ,animated: true,completion: nil)
            
        }
        
        
    }
    
    func insertData()  {
               
       let Cardmo1 = NSEntityDescription.insertNewObject(forEntityName: Czhanghaomo, into: context) as! ZhanghaoMO
       Cardmo1.number = zhanghaoTwo.text
       Cardmo1.password = mimaTwo.text

                   appDelegate.saveContext()

               }

}
