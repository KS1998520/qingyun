//
//  AddRemindViewController.swift
//  lbiao
//
//  Created by 16 on 2020/1/4.
//  Copyright © 2020 16. All rights reserved.
//

import UIKit
import EventKit

class AddRemindViewController: UIViewController {

   var eventStore: EKEventStore!
        //提醒信息文本框
    @IBOutlet weak var reminderTextField: UITextField!
    // @IBOutlet weak var reminderTextField: UITextField!
        //提醒时间文本框
    @IBOutlet weak var dateTextField: UITextField!
    //   @IBOutlet weak var dateTextField: UITextField!
        //提醒日期选择器
        var datePicker: UIDatePicker!
         
        override func viewDidLoad() {
            super.viewDidLoad()
             
            self.eventStore = EKEventStore()
             
            //设置提醒时间文本框使用的日期选择器
            datePicker = UIDatePicker()
            datePicker.addTarget(self, action: #selector(AddRemindViewController.addDate),
                                 for: .valueChanged)
            datePicker.datePickerMode = .dateAndTime
            dateTextField.inputView = datePicker
        }
         
        //日期选择器响应方法
    @objc func addDate(){
            //日期样式
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy年MM月dd日 HH:mm"
            //更新提醒时间文本框
            self.dateTextField.text = formatter.string(from: datePicker.date)
        }
         
        //保存按钮响应办法
    //    @IBAction func addReminder(_ sender: AnyObject) {
    @IBAction func addReminder(_ sender: Any) {
    
    //获取"提醒"的访问授权
            self.eventStore.requestAccess(to: .reminder) {
                (granted: Bool, error: Error?) in
                 
                //创建提醒条目
                DispatchQueue.main.async {
                    
                 let reminder = EKReminder(eventStore: self.eventStore)
                reminder.title = (self.reminderTextField.text)!
                let dueDateComponents = self.dateComponentFrom(date: self.datePicker.date)
                reminder.dueDateComponents = dueDateComponents
                reminder.calendar = self.eventStore.defaultCalendarForNewReminders()
                //保存提醒事项
                do {
                    try self.eventStore.save(reminder, commit: true)
                    let alert = UIAlertController(title: "添加成功", message: nil, preferredStyle: .alert)
                                    alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
                    self.present(alert ,animated: true,completion: nil)
                }catch{
                     let alert = UIAlertController(title: "添加失败", message: nil, preferredStyle: .alert)
                                    alert.addAction(UIAlertAction(title: "知道了", style: .cancel, handler: nil))
                    self.present(alert ,animated: true,completion: nil)
                }
            }
        }
    }
        //根据NSDate获取对应的DateComponents对象
        func dateComponentFrom(date: Date)-> DateComponents{
            let cal = Calendar.current
            let dateComponents = cal.dateComponents([.minute, .hour, .day, .month, .year],
                                                    from: date)
            return dateComponents
        }
         
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
    }
